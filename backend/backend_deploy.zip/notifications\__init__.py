# Notification module initialization
